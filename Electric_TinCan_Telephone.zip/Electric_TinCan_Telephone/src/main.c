//C21475366 Jennifer O'Reilly
//TinCan Telephone Project
// This project uses USART to communicate between two Nucleo boards.
// The sent and recieved message are dislpayed on the LCD screen using SPI.
// 3 LEDS monitor they state of the system, sending, recieving and idle.
// A potentiometer on the VCC of the LCD is used to dim the display.
#include <eeng1030_lib.h>
#include <stdio.h>
#include  <errno.h>
#include  <sys/unistd.h> // STDOUT_FILENO, STDERR_FILENO
#include "circular_buffer.h"
#include "display.h"

#define enable_interrupts() asm(" cpsie i ") // enable global interrupts 
#define diable_interrupt() asm (" cpsid i") //disable global interrupts
#define INPUT_BUFFER_SIZE CIRC_BUF_SIZE
#define LINE_HEIGHT 10
#define SCREEN_HEIGHT 80
#define SCREEN_WIDTH 160 
#define NUM_LINES 8
void setup(void);
void delay_ms(volatile uint32_t dly);
void initSerial(uint32_t baudrate);
void eputc(char c);
void readInputMessage();
void sendMessage(char *message);
void clearReceivedMessage(char *buffer, int size);
int count;
circular_buffer rx_buf;          //Circular buffer structure defined in circular buffer.h
volatile uint32_t data_ready=0;// flag to indicate when new data is available in the buffer
volatile char input_buffer[INPUT_BUFFER_SIZE]; // Store user-typed message
volatile uint8_t input_index = 0;// index to track where the input is beinf written in the buffer
volatile uint8_t input_ready = 0;// flag to indicate when the input is ready for processing
int currentLine = 0;// line counter to track the current line number for printing


int main()
{
    char message_received[CIRC_BUF_SIZE]; // This buffer will store recieved messages
    setup(); // initialising the setup of the system
    init_display();// initialise the LCD to display messages sent or recieved
    
    init_circ_buf(&rx_buf);//initialise the circular buffer
    NVIC->ISER[1] |= (1 << (38-32)); // enabling the USART2 interrupt
    NVIC->ISER[1] |= (1 << (37-32));// enabling the USART1 interrupt
    enable_interrupts(); //enable global interrupts

    while(1)
    {
        
        readInputMessage();// reading the user input from USART2
        if (input_ready)// if the message is done, gets sent via USART1
        {
            sendMessage(input_buffer);
            input_ready = 0;
            GPIOB->ODR &= ~(1 << 0);  // since the message is being sent, the 
            //LED comes out of idle state, so the sent LED will turn on.
        }
  
        if (data_ready) // if a message has been recieved via USART1, it will be processed and displayed.
        {
            int i = 0;
            char c;
            // Continue to retrieve characters while get_circ_buf() returns 0 (success)
            while(get_circ_buf(&rx_buf, &c) == 0)
            {
                message_received[i++] = c;
            }
            message_received[i+1] = '\0';   // Terminate the string
            printf("CLAIRE: %s\n",message_received);// print the recieved message from claires bord to the serial monitor
            GPIOB->ODR |= (1 << 4);//Recieved LED on
            delay_ms(5000000);// short delay to give a flash of the LED
            GPIOB->ODR &= ~(1 << 4);//Recieved LED off
            
            printMessage(1,message_received);// print the message on the display
            
            clearReceivedMessage(message_received, CIRC_BUF_SIZE);// clear the message buffer
            data_ready = 0;
            GPIOB->ODR &= ~(1 << 0);  // Turn off Idle LED
        }
        // Check if neither sending nor receiving is happening
    if (!(input_ready) && !(data_ready))
    {
        // Turn on Idle LED if neither send nor receive is active
        GPIOB->ODR |= (1 << 0);  // Turn on Idle LED
    }
        
    }
}
void delay_ms(volatile uint32_t dly)//simple delay function by implementing a counter
{
    while(dly--);
    
}
void setup()
{
    initClocks();  //set up the system clocks  
    RCC->AHB2ENR |= (1 << 0) + (1 << 1); // enable GPIOA and GPIOB
    initSerial(9600);//enable serial communication with 9600 baud rate.
    pinMode(GPIOB,4,1);// LED for notification of recieved message P
   
    pinMode(GPIOB,5,1);//LED for notification of sent message PB5
    pinMode(GPIOB, 0, 1);  // Set PB0 as output for IDLE state LED

    
    
}
//configure USART1 and USART2 for serial communication
void initSerial(uint32_t baudrate)
{
    RCC->AHB2ENR |= (1 << 0); // make sure GPIOA is turned on
    pinMode(GPIOA,2,2); // tx for serial monitor
    selectAlternateFunction(GPIOA,2,7); // AF7 = USART2 TX
    pinMode(GPIOA,15,2); //rx for serial monitor
    selectAlternateFunction(GPIOA,15,3);   //AF3 = USART2 RX
    RCC->APB1ENR1 |= (1 << 17); // turn on USART2
    
    pinMode(GPIOA,9,2); // tx for Nucleo board communication
    selectAlternateFunction(GPIOA,9,7); // AF7 = USART1 TX
    pinMode(GPIOA,10,2); // rx for Nucleo board communication
    selectAlternateFunction(GPIOA,10,7);   //AF7 = USART1 RX
    

    RCC->APB2ENR |= (1 << 14); // turn on USART1
    //set baud rate
    const uint32_t CLOCK_SPEED=80000000;    
    uint32_t BaudRateDivisor;
    
    //calculate the baudrate divisor based on the system clock and desired baud rate
    BaudRateDivisor = CLOCK_SPEED/baudrate; 
    USART1->CR1 = 0;//clear control register 1
    USART1->CR2 = 0;//clear control register 2
    USART1->CR3 = (1 << 12); // disable over-run errors
    USART1->BRR = BaudRateDivisor;// set the baud rate to the calculated divisor
    USART1->CR1 =  (1 << 3);  // enable the transmitter and receiver
    USART1->CR1 |=  (1 << 2);  // enable the transmitter and receiver
    USART1->CR1 |= (1 << 0);//enable USART1
    USART1->CR1 |= (1 << 5); // enable interrupt for reiceved data RXNE
    USART1->ICR = (1 << 1);// clear interrupt flag in USART1 ORE

    USART2->CR1 = 0;//clear control register 1
    USART2->CR2 = 0;//clear control register 2
    USART2->CR3 = (1 << 12); // disable over-run errors
    USART2->BRR = BaudRateDivisor;// same as above
    USART2->CR1 =  (1 << 3);  // enable the transmitter and receiver
    USART2->CR1 |=  (1 << 2);  // enable the transmitter and receiver
    USART2->CR1 |= (1 << 0);// same as above
}

// This function allows printf to send data over serial by writing each character
// to the USART2 transmit register (TDR) using the eputc() function.
int _write(int file, char *data, int len)//file where data has been written, 
{
    if ((file != STDOUT_FILENO) && (file != STDERR_FILENO))
    {
        errno = EBADF;
        return -1;
    }
    while(len--)
    {
        eputc(*data);    
        data++;
    }    
    return 0;
}
void eputc(char c)
{
    while( (USART2->ISR & (1 << 6))==0); // wait for ongoing transmission to finish
    USART2->TDR=c;
} 

void readInputMessage()
{
    char c;
    while (USART2->ISR & (1 << 5))  // Check if data is available from the Serial Monitor
    {
        c = USART2->RDR; // Read character from Serial Monitor

        if (c == '\r' || c == '\n')  // If Enter is pressed, process input
        {
            input_buffer[input_index] = '\0';  // Null-terminate string
            input_ready = 1;  // Set flag that input is ready
            input_index = 0;  // Reset buffer index
        }
        else if (input_index < INPUT_BUFFER_SIZE - 1) 
        {
            input_buffer[input_index++] = c;  // Store character in input buffer
        }
    }
}

//function to send a message via USART1 
void sendMessage(char *message)
{
    GPIOB->ODR &= ~(1 << 0);// set the idle LED to low
    GPIOB->ODR |= (1 << 5);// set the sent LED to high
    
    delay_ms(5000000);// short delay to create flash of LED
    GPIOB->ODR &= ~(1 << 5);// turn sent LED to low
    
    printMessage(0,message);//display message on the serial monitor
    while (!(USART1->ISR & (1 << 6))); // Wait for TX buffer to be empty
    USART1->TDR = '[';  // Start message with '[', marks the beginning of a new message

    while (*message)//iterate over the message until the end
    {
        while (!(USART1->ISR & (1 << 6))); // Wait for TX ready(TX buffer empty)
        USART1->TDR = *message++; // send the current character and move to the next.
    }

    while (!(USART1->ISR & (1 << 6))); // Wait for TX buffer to be empty
    USART1->TDR = ']';  // End message with ']', signifies end of current message
    printf("JEN:%s\n", message);  // Show sent message in Serial Monitor
    
}

//function to clear the contents of the buffer by setting each byte to NULL
void clearReceivedMessage(char *buffer, int size)
{
    for (int i = 0; i < size; i++)//loop through each element of the buffer and set it to NULL
    {
        buffer[i] = '\0';// this will NULL-terminate the string at each index
    }
}



void USART1_IRQHandler(void)
{
    // Check if RXNE (Receive Not Empty) flag is set
    if (USART1->ISR & (1 << 5))
    {
        char c = USART1->RDR; // Read the received character
        if (c == '[')
        {
            // Reset/clear the circular buffer
            init_circ_buf(&rx_buf);
            // Indicate that we are now receiving a message
            message_started = 1;
        }
        else if (c == ']')
        {
            // Only mark data as ready if we were actually receiving a message
            if (message_started)
            {
                data_ready = 1;
                message_started = 0; // End of message
            }
        }
        else
        {
            // Store characters only if we're inside a message
            if (message_started)
            {
                put_circ_buf(&rx_buf, c);
            }
        }
    }
}
//function to print on LCD display
void printMessage(int i, const char *message) {
    uint16_t y = currentLine * LINE_HEIGHT;
    GPIOB->ODR &= ~(1 << 0);
    // Received message will appear at the top left (first 4 lines)
    if (i == 1) {// if i is 1, then it is a recieved message
        if (currentLine >= NUM_LINES) {
            fillRectangle(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT, 0x00);
            currentLine = 0; // reset line to 0 to start printing from top of screen again
        }
        printText(message, 0, y, RGBToWord(255, 20, 147), RGBToWord(0, 0, 0));//message will be in pink
        currentLine++;//increment the current line to make room for next message
    } else {// if i is 0 then it is a sent message
        // Sent message will appear at the bottom left
        if (currentLine >= NUM_LINES) {
            //if there are no more lines to display messages, clear the screen
            fillRectangle(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT, 0x00);
            currentLine = 0;// reset line to 0 to start printing from top of screen again
        }
        // sent message with x offset of 50  from the left
        //message will be white
        printText(message, 50, y, RGBToWord(255, 255, 255), RGBToWord(0, 0, 0));
        currentLine++;//increment current line for next message
    }
}



